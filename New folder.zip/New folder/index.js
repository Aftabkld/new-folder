const express = require('express');
const cors = require('cors');
const mongoose =require('mongoose');
const todomodel=require('./model/todomodel');
const con =mongoose.connect("mongodb://127.0.0.1:27017/todo");
con.then(()=>{
    console.log("connection succesfull");
});
con.catch(()=>{
    console.log("error in connection");
});
const app= express();
app.use(express.json());
app.use(cors());
app.post("/todo",async (req ,res)=>{
    var todo= req.body.todo;
   
    const rec =new todomodel({
        todo:todo

    });
    await rec.save();
    res.json({msg:"Record Saved"});

});

app.put("/todo",async(req ,res)=>{
    var todo= req.body.todo;
   var tid= req.body.id;
   const rec= await todomodel.findOneAndUpdate({_id:tid},{todo:todo});
   res.send(rec);
   res.json({msg:"Record Update"});


    });
   
    
        app.get("/todo/:id",async(req,res)=>{
            const rec  =await todomodel.findOne({_id:req.params.id});
            res.send(rec);
        });
        app.get("/todo",async(req,res)=>{
            const rec  =await todomodel.find();
            res.send(rec);
        });
 
        app.delete("/todo",async(req,res)=>{
            const tid  =req.body.tid;
            await todomodel .findOneAndDelete({"_id":tid});
            res.json({msg:"Record Deleted"});
           
            });

            
app.listen(5000,()=>{
    console.log("server started");
}); 
