const mongoose=require('mongoose');
const todomodel= mongoose.model("todo", new mongoose.Schema({
    todo:{type:String, required:true}
   
    
}));
module.exports=todomodel