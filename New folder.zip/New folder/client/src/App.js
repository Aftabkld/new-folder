
import './App.css';
import Inputlist from './component/Inputlist';

function App() {
  return (
    <>
   <Inputlist/>
    </>
  );
}

export default App;
