
import React from 'react'
import { useState,useEffect } from 'react';

function Inputlist() {
  const [ar, setar]=useState([]);
    useEffect(()=>{
      getrecord();
    },[])
    const[frm, setfrm]=useState({txttodo:"",edttodo:"", });
    const fun1=(e)=>{
      setfrm({...frm,[e.target.id]:e.target.value});
    }
  
    const editrecord=async(x)=>{
      const resp=await fetch("http://localhost:5000/todo/"+x,{
        method:"GET",
        headers:{'Content-Type':'Application/json'}
      });
      const result=await resp.json();
      setfrm({...frm,edttodo:result.todo, edtid:x})
      
    }
  
    const updaterecord=async()=>{
  
      const resp=await fetch("http://localhost:5000/todo",{
        method:"PUT",
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({todo:frm.edttodo,tid:frm.edtid})
      });
      const result=await resp.json();
      alert(result.msg);
      getrecord();
  
    }
  
    const deleterecord=async(m)=>{
      if(window.confirm("Want to delete"))
      {
        const resp=await fetch("http://localhost:5000/todo",{
          method:"DELETE",
          headers:{'Content-Type':'Application/json'},
          body:JSON.stringify({tid:m})
        });
        const result=await resp.json();
        alert(result.msg);
        getrecord();
      }
    }
    const saverecord=async()=>{
      const resp=await fetch("http://localhost:5000/todo",{
        method:"POST",
        headers:{'Content-Type':'Application/json'},
        body:JSON.stringify({todo:frm.txttodo})
      });
      const result=await resp.json();
      alert(result.msg);
      getrecord();
    } 
    const getrecord=async()=>{
      const resp=await fetch("http://localhost:5000/todo",{
        method:"GET",
        headers:{'Content-Type':'Application/json'},
      }); 
      const result= await resp.json();
      setar(result)
    }
    
  return (
    <>
    <div className='container text-center bg-light'>
    <table className="table bg-ligt text-dark">
    <thead>
                    <tr>
                      <th scope="col"><h2>todolist</h2></th>
                      <td> <button type="button" className="btn btn bg-dark text-light" data-bs-toggle="modal" data-bs-target="#exampleModal">
                          Add Data
                    </button></td>
                    </tr>
                  </thead>
    

    <tbody>
                  {ar.map((x)=>{
                    return(
                      <tr className="bg-light text-dark">
                        <td >{x.todo}</td>
                       
                        <td><button className="btn btn-dark text-light" onClick={()=>{editrecord(x._id)}} data-bs-toggle="modal" data-bs-target="#editModal">Edit</button> &nbsp; &nbsp;<button className="btn btn-dark text-light" onClick={()=>{deleterecord(x._id)}}>Delete</button></td>
                      </tr>
                    )
                  })}  
                  </tbody>
                  </table>
    </div>
   <div className="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div className="modal-dialog">
     <div className="modal-content">
       <div className="modal-header">
         <h5 className="modal-title" id="exampleModalLabel">todolist</h5>
         <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
       </div>
       <div className="modal-body">
         <div className='form-group'>
           <label>todo</label>
           <input id='txttodo' type='text' value={frm.txttodo} onChange={fun1} className='form-control' />
         </div>
       </div>
       <div className="modal-footer">
         <button type="button" onClick={saverecord} className="btn btn-primary">Submit</button>
       </div>
     </div>
   </div>
 </div>
 <div className="modal fade" id="editModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title" id="exampleModalLabel">Update Record</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div className="modal-body">
          <div className='form-group'>
            <label>todolist</label>
            <input id='edttodo' type='text' value={frm.edttodo} onChange={fun1} className='form-control' />
          </div>
        </div>
        <div className="modal-footer">
          <button type="button" onClick={updaterecord}  className="btn btn-primary">Submit</button>
        </div>
      </div>
    </div>
  </div>
  </>
  )
}

export default Inputlist
